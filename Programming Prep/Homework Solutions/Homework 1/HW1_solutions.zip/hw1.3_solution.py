
# File: hw1.3_solution.py
# Author(s):  SOLUTION

import numpy as np   # random numbers, inf

# 3.a -- rod cutting

# we modify the algorithm to keep track of the maximum revenue and
# the rod cuts at each step.  this version includes the end of the
# rod as a "cut", but you can leave that final "cut" out if you wish.

def price(i):
    if i >= 1 and i <= 4:
        return [0, 1, 5, 8, 9][i]
    return 0

M = {}     # dict of already computed values AND CUTS
def Rev(N):
    if N in M:
        return M[N]
    mxrevcuts = [0, []]   # 0 revenue, no cuts
    if N == 1:
        mxrevcuts = [price(N), [N]]   # one "cut" at end of rod
    else:
        for k in range(1,N+1):  # [1..N]
            revcuts_Nk = Rev(N-k)
            if price(k) + revcuts_Nk[0] > mxrevcuts[0]:
                mxrevcuts = [price(k) + revcuts_Nk[0], [k]]
                for i in range(len(revcuts_Nk[1])):
                    mxrevcuts[1].append(revcuts_Nk[1][i] + k)
    M[N] = mxrevcuts
    return mxrevcuts

# 3.a test code:

print('\n3.a:\n')
for i in range(21):
    rev, cuts = Rev(i)
    print('N: {:2d}, max rev: {:3d}, cuts:'.format(i, rev), cuts)


# 3.b -- weighted shortest distance, graph from lecture notes

print('\n\n3.b:\n')

# it is not necessary to define a function for this, but it seems
# straightforward after getting A0, ..., A4 working

def WeightedShortestDistance(A0):    # A0 should be a square ndarray
    Ak = []   # the list of A0, ..., Ak matrices
    Ak.append(A0)

    dimA0 = Ak[0].shape[0]
    for node in range(1, dimA0 + 1):
        Ak.append(np.zeros((dimA0, dimA0)))
        for s in range(dimA0):
            for t in range(dimA0):
                Ak[node][s, t] = min(Ak[node-1][s, t],
                                     Ak[node-1][s, node-1] + Ak[node-1][node-1, t]) 
    return Ak[dimA0]


A0 = np.array([ [      0, np.inf, np.inf,     1 ],
                [      2,      0,      4,     5 ],
                [ np.inf, np.inf,      0,     3 ],
                [ np.inf,      7,      1,     0 ] ])
print('\nA0:\n', A0)

A4 = WeightedShortestDistance(A0)
print('\nA4:\n', A4)


# 3.c -- weighted shortest distance, larger graph

print('\n\n3.c:\n')

A0 = np.array([ [      0,      6, np.inf,      1, np.inf, np.inf,      3 ],
                [ np.inf,      0,      2, np.inf, np.inf,      4, np.inf ],
                [ np.inf, np.inf,      0,      4, np.inf, np.inf, np.inf ],
                [ np.inf, np.inf, np.inf,      0,     10, np.inf,      2 ],
                [ np.inf, np.inf,      1, np.inf,      0,      1, np.inf ],
                [ np.inf, np.inf,      4, np.inf,      1,      0, np.inf ],
                [      2,      1, np.inf, np.inf, np.inf, np.inf,      0 ] ])
print('\nA0:\n', A0)

A7 = WeightedShortestDistance(A0)
print('\nA7:\n', A7)

