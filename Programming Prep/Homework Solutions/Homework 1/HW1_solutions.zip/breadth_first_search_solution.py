   
# File: breadth_first_search_solution.py
# Authors: SOLUTION

def BFS(G, root, target):
   S = { root }           # the set of processed nodes
   T = { root : None }    # node -> parent
   Q = [ root ]
   while Q:
      cur = Q.pop(0)
      if cur == target:
         parent_list = [ cur ]
         while T[cur] != None:
            parent_list.append(T[cur])
            cur = T[cur]
         parent_list.reverse()
         return parent_list
      for v in G[cur]:
         if v not in S:
            S.add(v)
            T[v] = cur
            Q += [v]
   # root and target are not in the same connected component, if we get here
   return [ root, ' *** NO PATH TO *** ', target ]

# 1.c (function definitions)
#'''
def BFS_con_comps(G):   # return a list of connected components in G,
                        # where each connected component is a sorted
                        # list of nodes
   ret = []             # the list of connected components to return
   S = set()            # the set of all processed nodes
   for node in G:
      if node not in S:    # then build a new connected component
         Scur = {node}     # nodes in current con. comp. (don't need tree)
         Q = [node]        # next nodes to check in current con. comp.
         while Q:
            cur = Q.pop()
            for v in G[cur]:
               if v not in Scur:
                  Scur.add(v)
                  Q += [v]
         S |= Scur         # add nodes in current con. comp. to S
         curcc = list(Scur)
         curcc.sort()
         ret.append(curcc) # append current con. comp. list to ret
         if len(S) == len(G):    # every node has been processed ...
            ret.sort()
            return ret           # so we are done
   ret.sort()
   return ret    # should not get here

def print_con_comps(G_cc):  # display connected components
   print('graph contains', len(G_cc), 'connected components:')
   for i in range(len(G_cc)):
      print('{:5d}:'.format(i + 1), G_cc[i])
   
#'''

def main():

# 1.a (test code)
   G = { 'A' : [ 'B', 'J', 'Me' ],
         'B' : [ 'A' ],
         'C' : [ 'D', 'P' ],
         'D' : [ 'C', 'O' ],
         'E' : [ 'F', 'J', 'K' ],
         'F' : [ 'E', 'M' ],
         'G' : [ 'K', 'S', 'Ed' ],
         'H' : [ 'O', 'U' ],
         'Me': [ 'A', 'I', 'N', 'V' ],
         'I' : [ 'Me', 'Q' ],
         'J' : [ 'A', 'E', 'L', 'Q', 'W' ],
         'K' : [ 'E', 'G' ],
         'L' : [ 'J', 'W' ],
         'M' : [ 'E', 'S', 'T' ],
         'N' : [ 'Me', 'V' ],
         'O' : [ 'H', 'D' ],
         'P' : [ 'C', 'U' ],
         'Q' : [ 'I', 'J', 'X', 'Y' ],
         'R' : [ 'Ed' ],
         'S' : [ 'G', 'M', 'Y', 'Z' ],
         'T' : [ 'M' ],
         'U' : [ 'H', 'P' ],
         'V' : [ 'Me', 'N' ],
         'W' : [ 'J', 'L' ],
         'X' : [ 'Q', 'Y' ],
         'Y' : [ 'Q', 'S', 'X', 'Z' ],
         'Ed': [ 'G', 'R', 'Z' ],
         'Z' : [ 'S', 'Y', 'Ed' ] }
   print('Shortest path from Me to Ed:', BFS(G, 'Me', 'Ed'))

# 1.b (test code)
#'''
   print('Shortest path from A to I:  ', BFS(G, 'A', 'I'))
   print('Shortest path from B to R:  ', BFS(G, 'B', 'R'))
   print('Shortest path from C to H:  ', BFS(G, 'C', 'H'))
   print('Shortest path from M to T:  ', BFS(G, 'M', 'T'))
#'''
# optional:
   print('Shortest path from A to C:  ', BFS(G, 'A', 'C'))

# 1.c (test code)
#'''
# connected components tests:
   G2 = { 'A': ['B', 'C'],
          'C': ['A'],
          'E': ['F'],
          'D': [],
          'B': ['A'],
          'F': ['E'] }
   G2_cc = BFS_con_comps(G2)
   print_con_comps(G2_cc)
   G_cc = BFS_con_comps(G)
   print_con_comps(G_cc)

#'''

if __name__ == '__main__':
   main()
