
# File: hw2_1_solution.py
# Author(s):  SOLUTION

import numpy as np   # random numbers, inf

# 1.a -- maximum sublist sum (Kadane's algorithm)

# see: https://en.wikipedia.org/wiki/Maximum_subarray_problem

def max_sublist_sum(vals):
    best_sum = 0
    cur_sum = 0
    for x in vals:
        cur_sum = max(0, cur_sum + x)
        best_sum = max(best_sum, cur_sum)
    return best_sum

# 1.a test code:

print('\n\n1.a:\n')

np.random.seed(1)   # so results match

list1 = [2, -4, 7, 2, 0, 5, -3, 4, -2]
print("max_sublist_sum(", list1,
               "): ", max_sublist_sum(list1))

for n in range(10, 20):
    listn = list(np.random.randint(-5, 9, size=n))
    print("max_sublist_sum(", listn,
                   "): ", max_sublist_sum(listn))

# 1.b -- 0/1 Knapsack algorithm

# item_wgts is a list of integer item weights
# item_vals is a list of integer item values
# tot_wgt is the integer total weight that will fit into the knapsack

def knapsack01(item_wgts, item_vals, tot_wgt):
    # (in real life we should check that that lengths of item_wgts and
    #  item_vals are the same, and that all argument values are integers > 0)
    nrows = len(item_wgts)
    ncols = tot_wgt + 1
    
    # we need an array of (# items) rows by (tot_wgt+1) columns
    # we could use a list of lists, or an ndarray
    
    # list of lists version using nested comprehension:
    # A = [ [ 0 for col in range(tot_wgt+1) ] for row in range(len(item_wgts)) ]
    
    # ndarray version: initialize all cells with 0 (although not necessary)
    A_shape = (nrows, ncols)   # shape parameter is a tuple
    A = np.zeros(A_shape, dtype=np.int32)  # okay to use default dtype of float
    
    # first row
    row = 0
    for col in range(min(ncols,item_wgts[row])):
        A[row, col] = 0
    for col in range(item_wgts[row], ncols):
        A[row, col] = item_vals[row]

    # remaining rows
    for row in range(1, nrows):
        it_wgt = item_wgts[row]
        it_val = item_vals[row]
        for col in range(min(ncols,it_wgt)):
            A[row, col] = A[row-1, col]
        for col in range(it_wgt, ncols):
            A[row, col] = max(A[row-1, col], it_val + A[row-1, col-it_wgt])

    # if you would like to see the final A, uncomment these
    '''
    print('item_wgts:', item_wgts)
    print('item_vals:', item_vals)
    print('tot_wgt:  ', tot_wgt)
    print('final A:')
    print(A)
    '''
    
    # return the value of the lower right cell
    return A[nrows-1, ncols-1]

# 1.b test code

print('\n\n1.b:\n')

item_weights = [3, 1, 12, 5, 2]
item_values = [9, 7, 18, 3, 11]
total_weight = 10

# output: 27
print("max value:",
        knapsack01(item_weights, item_values,
                   total_weight))

item_weights = [2, 3, 5, 1, 12]
item_values = [11, 9, 3, 7, 18]
total_weight = 10

# output: 27
print("max value:",
        knapsack01(item_weights, item_values,
                   total_weight))

item_weights = [2, 4, 9, 3, 12, 4, 1, 3]
item_values = [8, 4, 2, 11, 9, 5, 2, 8]
total_weight = 20

# output: 38
print("max value:",
        knapsack01(item_weights, item_values,
                   total_weight))


# 1.c -- Minimum Number of Coins algorithm

# coins is a list of integer denominations of coins (>0, no duplicates)
# value is the integer total value of change to be made from the coins

def min_coins(coins, value):
    # (in real life, we should check the parameters)
    
    # we need an array of (value+1) cells, initialized to (value+1)
    A = [ value+1 for j in range(value+1) ]

    # loop through the coin denominations
    for coin in coins:
        if coin <= value:
            A[coin] = 1
            for j in range(coin+1, value+1):
                A[j] = min(A[j], 1 + A[j-coin])

    # if you would like to see the final A, uncomment these
    '''
    print('coins:', coins)
    print('value:', value)
    print('final A:')
    print(A)
    '''
    
    # the value of the final cell, OR -1 if the final cell is value+1
    return A[value] if A[value] != value+1 else -1

# 1.c test code

print('\n\n1.c:\n')

coins = [2, 3, 6]
value = 10

print("value", value, "requires",
           min_coins(coins, value), "coins minimum")


coins = [1, 5, 10, 25]
value = 117

print("value", value, "requires",
           min_coins(coins, value), "coins minimum")


coins = [1, 5, 10, 18, 25, 37]
value = 273

print("value", value, "requires",
           min_coins(coins, value), "coins minimum")


